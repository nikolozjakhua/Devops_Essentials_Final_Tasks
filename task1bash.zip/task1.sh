#!/bin/bash

#Make input variable and IFS to comma separated values
INPUT=$1
IFS=,
list_of_emails=()

#get directory of input
NEW_PATH=$(dirname $1)
FILE="$NEW_PATH/accounts_new.csv"
DOMAIN="@abc.com"

#If file doesn't exists, make header.
if ! test -f "$FILE"; then
  cat $1 | head -n 1 >> $FILE
fi

#Function for build up new email address
get_info () {
  first_name=$1
  last_name=$2

  email=$(echo "${first_name::1}$last_name$DOMAIN" | awk '{print tolower($1)}')
  list_of_emails+=($email)
}

#Make List of new usermails to check if it has duplicates
while read -r id location_id name title email department
do
    first_name=$(echo $name | awk '{print $1}')
    last_name=$(echo $name | awk '{print $2}')

    get_info $first_name $last_name
done < <(tail -n +2 $1)
#Get list of duplicates
duplicates=$(printf '%s\n' "${list_of_emails[@]}"|awk '!($0 in seen){seen[$0];next} 1')

#Final loop for new CSV file
while IFS=, read -r id location_id name title email department
do
    #split name into first and last name
    first_name=$(echo $name | awk '{print $1}')
    last_name=$(echo $name | awk '{print $2}')

    #make first and lastname's first letter uppercase
    first_upper=${first_name^}
    last_upper=${last_name^}
    name=$(echo $first_upper $last_upper)    

    #Check if Title has double quotes or commas.
    if [[ $title == *'"'* ]]; then
      IFS=""
      title=$(printf "\""$title,$email"\"" | tr -d '"')
    fi
    
    #check duplicate values, add locationid in email if true, declare email
    email=$(echo "${first_name::1}$last_name$DOMAIN" | awk '{print tolower($1)}')
    if [[ "${duplicates}" =~ "${email}" ]]; then
        email=$(echo "${first_name::1}$last_name$location_id$DOMAIN" | awk '{print tolower($1)}')
    fi

    #Save result to a new file
    printf "%s,%s,%s,\""%s"\",%s,%s" "$id" "$location_id" "$name" "$title" "$email" "$department" >> $FILE
done < <(tail -n +2 $1) # pass csv file in while loop without header
