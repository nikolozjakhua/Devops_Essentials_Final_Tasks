#!/bin/bash

INPUT=$1
INPUT_PATH=$(dirname $1)
NEW_FILE="$INPUT_PATH/output.json"

#Get test name from the brackets.
test_name=()
first_line=$(cat $INPUT | head -n 1)
for word in $first_line; do
    if [[ $word == "[" ]]; then
        continue
    elif [[ $word == "]," ]]; then
        break
    fi
    test_name+=($word)
done
#
name_of_tests=${test_name[@]}

printf '{\n "testName":"%s",\n "tests": [\n' "$name_of_tests" >> $NEW_FILE

##count how much tests passed in 
range_of_tests=$(echo $first_line | awk '{print $(NF-1)}')
END=$(echo $range_of_tests | awk -F. '{print $NF}')
last_line_of_tests=$(awk "NR==(($END+2))" $INPUT)

#while loop for file
while read -r line;
do
#if line contains dashes go to next line
if [[ $line =~ "----" ]]; then
    continue
fi

#make list's with each line. and make list for test Name
sentence=()
word=()
for i in $line; do
    sentence+=($i)
done
len=${#sentence[@]}
if [[ ${sentence[0]} == "not" ]]; then
    for (( i=3; i<$len-1; i++ )); do 
        word+=(${sentence[$i]})
    done
else
    for (( i=2; i<$len-1; i++ )); do 
        word+=(${sentence[$i]})
    done
fi

#Declare variables for keys
duration=${sentence[-1]}
name=${word[@]}
name=${name::-1}

#Declare Boolean variables
jobdone=true
failed=false

#Check if it is last line of the loop
if [[ ${line} == $last_line_of_tests ]]; then
    if [[ ${sentence[0]} == "not" ]]; then
        printf '{"name":"%s", "status":%s, "duration":"%s" }],' "$name" "$failed" "$duration" >> $NEW_FILE
        break
    else
        printf '{"name":"%s", "status":%s, "duration":"%s" }],' "$name" "$jobdone" "$duration" >> $NEW_FILE
        break
    fi
fi

#if condition for status true or false.
if [[ ${sentence[0]} == "not" ]]; then
    printf '{"name":"%s", "status":%s, "duration":"%s" },' "$name" "$failed" "$duration" >> $NEW_FILE
else
    printf '{"name":"%s", "status":%s, "duration":"%s" },' "$name" "$jobdone" "$duration" >> $NEW_FILE
fi

done < <(tail -n +2 $INPUT)

#Parse last line for summary values
last_line=$(cat $INPUT | tail -n 1)
last_line_list=()

for i in $last_line; do
    last_line_list+=($i)
done

success_rate=${last_line_list[0]}
failed_tests=${last_line_list[5]}
rating=${last_line_list[-3]}
rating=${rating::-2}
sum_of_duration=${last_line_list[-1]}


printf '\n"summary":{ "success":%s, "failed":%s, "rating":%s, "duration":"%s" }}' "$success_rate" "$failed_tests" "$rating" "$sum_of_duration" >> $NEW_FILE


