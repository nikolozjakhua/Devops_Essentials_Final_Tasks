#!/bin/bash

INPUT=$1
INPUT_PATH=$(dirname $1)
NEW_FILE="$INPUT_PATH/output.json"

list_of_lines=()
test_name=()

#Get test name from the brackets.
first_line=$(cat $INPUT | head -n 1)
for word in $first_line; do
    if [[ $word == "[" ]]; then
        continue
    elif [[ $word == "]," ]]; then
        break
    fi
    test_name+=($word)
done
#
name_of_tests=${test_name[@]}

printf '{\n "testName":"%s",\n "tests": [\n' "$name_of_tests" >> $NEW_FILE

##count how much tests passed in 
range_of_tests=$(echo $first_line | awk '{print $(NF-1)}')
END=$(echo $range_of_tests | awk -F. '{print $NF}')
last_line_of_tests=$(awk "NR==(($END+2))" $INPUT)

#Declare test success rate and sum of duration
success_rate=0
sum_of_duration=0

#while loop for file
while read -r line;
do
#if line contains dashes go to next line
if [[ $line =~ "----" ]]; then
    continue
fi

#make list's with each line. and make list for test Name
sentence=()
word=()
for i in $line; do
    sentence+=($i)
done
len=${#sentence[@]}
for (( i=3; i<$len-1; i++ )); do 
    word+=(${sentence[$i]})
done

#Declare variables for dict keys
duration=${sentence[-1]}
name=${word[@]}
name=${name::-1}
duration_numbers_only=$(echo $duration | awk -F"ms" '{print $1}')
(( sum_of_duration += duration_numbers_only ))

#Declare Boolean variables
jobdone=true
failed=false

#Check if it is last line of the loop
if [[ ${line} == $last_line_of_tests ]]; then
    if [[ ${sentence[0]} == "not" ]]; then
        printf '{"name":"%s", "status":%s, "duration":"%s" }],' "$name" "$failed" "$duration" >> $NEW_FILE
        break
    else
        printf '{"name":"%s", "status":%s, "duration":"%s" }],' "$name" "$jobdone" "$duration" >> $NEW_FILE
        (( success_rate += 1))
        break
    fi
fi

#if condition for status true or false.
if [[ ${sentence[0]} == "not" ]]; then
    printf '{"name":"%s", "status":%s, "duration":"%s" },' "$name" "$failed" "$duration" >> $NEW_FILE
else
    printf '{"name":"%s", "status":%s, "duration":"%s" },' "$name" "$jobdone" "$duration" >> $NEW_FILE
    (( success_rate += 1))
fi

done < <(tail -n +2 $INPUT)

#function for floating point number of rating 
calc() { awk "BEGIN{print $*}"; }

#Count rating and and % sign
rating=$(echo $(calc $success_rate*100/$END))
rating=$(printf "%0.2f\n" $rating)

failed_tests=$((END - success_rate))
sum_of_duration+=ms


printf '\n"summary":{ "success":%s, "failed":%s, "rating":%s, "duration":"%s" }}' "$success_rate" "$failed_tests" "$rating" "$sum_of_duration" >> $NEW_FILE

#I know it's a bit complex script, but used pure bash script without modules of Json. Json validator success. for prettier visual \n can be added in printf lines.