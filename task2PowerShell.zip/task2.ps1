param ([Parameter(Mandatory)][string]$filename)
$FILE=Import-Csv -Path $filename

#declare arrays for 
$name_list=@()
$location_id=@()
$title=@()
$email=@()
$department=@()
$domain="@abc.com"

#export rows from csv into lists
for ($i=0; $i -lt $FILE.count; $i++){
    $name_list+=$FILE[$i].name
    $location_id+=$FILE[$i].location_id
    $email+=$FILE[$i].email
    $title+=$FILE[$i].title
    $department+=$FILE[$i].department
}

#Capitalize all name first letters
$TextInfo = (Get-Culture).TextInfo
for ($i=0; $i -lt $name_list.count; $i++){
    $name_list[$i]=$TextInfo.ToTitleCase($name_list[$i])
    $FILE[$i].name=$name_list[$i]
}

#Make email name for each customer
for ($i=0; $i -lt $name_list.count; $i++){
    #split name and surname from name list
    $name=$name_list[$i].split()[0]
    $surname=$name_list[$i].split()[1]

    #extract first letter of name
    $first_letter_of_name=$name.substring(0,1)

    #make email name
    $email_name=$first_letter_of_name+$surname

    #make email address for each element in email row lowercased
    $email[$i]=$email_name.tolower()
}

#make list of duplicates in email list
$duplicates_list=@()
$ht = @{}
$email | foreach {$ht["$_"] += 1}
$ht.keys | where {$ht["$_"] -gt 1} | foreach {$duplicates_list+=$_}

#check if there are duplicates add location ID and domain, if not only domain
for ($i=0; $i -lt $email.count; $i++){
    $location=$location_id[$i]
    if ($duplicates_list -contains $email[$i]){
        $email[$i]=$email[$i]+$location+$domain
    }
    else {
        $email[$i]=$email[$i]+$domain
    }    
    $FILE[$i].email=$email[$i]
}


#Get full path of file passed in parameter
$PATH=Get-ChildItem -Path $filename | ForEach-Object{$_.FullName}

#Remove filename from Full path
$FILE_NAME=$PATH.split("\")[-1]
$PATH=$PATH.replace("$FILE_NAME", "")

$FILE | export-csv $PATH\accounts_new.csv -Append -notypeinformation
