#Parameters for string
param ([ValidateScript({$_ -match [IPAddress]$_ })][Parameter(Mandatory)][string]$ip_address_1,
[ValidateScript({$_ -match [IPAddress]$_ })][Parameter(Mandatory)][string]$ip_address_2,
[Parameter(Mandatory)][string]$network_mask)

#Convert to Binary function
function toBinary ($dottedDecimal){
    $dottedDecimal.split(".") | %{$binary=$binary + $([convert]::toString($_,2).padleft(8,"0"))}
    return $binary
}
#Convert to Decimal Function
function toDottedDecimal ($binary){
    do {$dottedDecimal += "." + [string]$([convert]::toInt32($binary.substring($i,8),2)); $i+=8 } while ($i -le 24)
    return $dottedDecimal.substring(1)
}
#Convert CIDR format to decimal function
function Cidr_To_Ipv4SubnetMask ($NetworkLength) {
    foreach ($Length in $NetworkLength) {
        $MaskBinary = ('1' * $Length).PadRight(32, '0')
        $DottedMaskBinary = $MaskBinary -replace '(.{8}(?!\z))', '${1}.'
        $SubnetMask = ($DottedMaskBinary.Split('.') | foreach { [Convert]::ToInt32($_, 2) }) -join '.'
        $SubnetMask
    }
}

#check if subnet is /32 and throw "No" to get rid of future errors
if(($network_mask -eq 32) -or ($network_mask -eq "255.255.255.255")){
    write-output "No"
    exit
}

#read args and convert to binary
$Ip_1_Binary = toBinary $ip_address_1
$Ip_2_Binary = toBinary $ip_address_2

#Check if network_mask parameter is in CIDR or SubnetMask format
try {
    $MaskBinary = Cidr_To_Ipv4SubnetMask $network_mask
    $MaskBinary = toBinary $MaskBinary
}
catch {
    $MaskBinary = toBinary $network_mask
}

#how many bits are the network ID
$netBits=$MaskBinary.indexOf("0")

#validate the subnet mask
If(($MaskBinary.length -ne 32) -or ($MaskBinary.substring($netBits).contains("1") -eq $true)) {
    Write-Warning "Subnet Mask is invalid!"
    Exit
}

#identify first IP address subnet boundaries
$networkID = toDottedDecimal $($Ip_1_Binary.substring(0,$netBits).padright(32,"0"))
$SubnetMask = toDottedDecimal $($MaskBinary.substring(0,$netBits).padright(32,"0"))
$broadCast = toDottedDecimal $($Ip_1_Binary.substring(0,$netBits).padright(32,"1"))

#Split IP address octets for comparison
$octets_1 = $ip_address_1.split(".")
$octets_2 = $ip_address_2.split(".")
$octets_subnet = $SubnetMask.split(".")


for ($i=0; $i -le 4; $i++){
    if(($octets_subnet[$i] -eq 255) -and ($octets_1[$i] -eq $octets_2[$i])){
        continue
    }
    elseif (($octets_subnet[$i] -eq 255) -and ($octets_1[$i] -ne $octets_2[$i])) {
        write-output "No"
        break
    }
    else {
        if(([int]$octets_2[$i] -ge $networkID.split(".")[$i]) -and ([int]$octets_2[$i] -le $broadCast.split(".")[$i])){
            Write-output "Yes"
            break
        }
        else {
            Write-output "No"
            break
        }
    }
}